#include "sensor.h"

#include <QDebug>

FlightSensor::FlightSensor(double value) : value_(value) {}

double FlightSensor::read()
{
    return value_;
}

bool FlightSensor::is_ready() const
{
    return ready_;
}

void FlightSensor::set_ready(bool ready)
{
    ready_ = ready;
}

Gyroscope::Gyroscope() : FlightSensor(1.25) {}

QString Gyroscope::name() const
{
    return QStringLiteral("Gyroscope");
}

Accelerometer::Accelerometer() : FlightSensor(9.81) {}

QString Accelerometer::name() const
{
    return QStringLiteral("Accelerometer");
}

Barometer::Barometer() : FlightSensor(1012.8) {}

QString Barometer::name() const
{
    return QStringLiteral("Barometer");
}

void check_sensors(const std::vector<Sensor*>& sensors)
{
    qDebug().noquote() << "Checking sensors...";
    bool allReady = !sensors.empty();
    for (Sensor* sensor : sensors) {
        if (sensor == nullptr) {
            qDebug().noquote() << "Sensor: missing";
            allReady = false;
        } else if (!sensor->is_ready()) {
            qDebug().noquote() << sensor->name() + QStringLiteral(": Not ready");
            allReady = false;
        } else {
            qDebug().noquote() << QStringLiteral("%1: Ready, value=%2")
                                      .arg(sensor->name()).arg(sensor->read());
        }
    }
    qDebug().noquote() << (allReady ? "All sensors are ready" : "sensor failure");
}
