#ifndef NAVIGATIONPANEL_H
#define NAVIGATIONPANEL_H

#include "navigation.h"

#include <QWidget>

class NavigationView;
class QCheckBox;
class QComboBox;
class QGroupBox;
class QLabel;
class QSpinBox;

class NavigationPanel : public QWidget {
public:
    explicit NavigationPanel(QWidget *parent = nullptr);

private:
    const NavigationSystem& selectedSystem() const;
    void refresh();

    GPSNavigation gps_;
    VisualNavigation visual_;
    QComboBox *systemSelector_;
    QGroupBox *gpsControls_;
    QGroupBox *visualControls_;
    QSpinBox *satelliteCount_;
    QCheckBox *gpsValid_;
    QCheckBox *targetTracked_;
    QLabel *status_;
    QLabel *reason_;
    QLabel *coordinates_;
    NavigationView *view_;
};

#endif // NAVIGATIONPANEL_H
