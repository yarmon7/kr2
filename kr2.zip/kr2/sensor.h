#ifndef SENSOR_H
#define SENSOR_H

#include <QString>

#include <vector>

class Sensor {
public:
    virtual double read() = 0;
    virtual bool is_ready() const = 0;
    virtual QString name() const = 0;
    virtual ~Sensor() = default;
};

class FlightSensor : public Sensor {
public:
    double read() override;
    bool is_ready() const override;
    void set_ready(bool ready);

protected:
    explicit FlightSensor(double value);

private:
    double value_;
    bool ready_ = true;
};

class Gyroscope final : public FlightSensor {
public:
    Gyroscope();
    QString name() const override;
};

class Accelerometer final : public FlightSensor {
public:
    Accelerometer();
    QString name() const override;
};

class Barometer final : public FlightSensor {
public:
    Barometer();
    QString name() const override;
};

void check_sensors(const std::vector<Sensor*>& sensors);

#endif // SENSOR_H
