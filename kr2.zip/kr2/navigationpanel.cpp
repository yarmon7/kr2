#include "navigationpanel.h"

#include <QCheckBox>
#include <QComboBox>
#include <QGroupBox>
#include <QHBoxLayout>
#include <QLabel>
#include <QPainter>
#include <QPushButton>
#include <QSpinBox>
#include <QVBoxLayout>

class NavigationView : public QWidget {
public:
    explicit NavigationView(QWidget *parent = nullptr) : QWidget(parent)
    {
        setMinimumHeight(210);
        setObjectName(QStringLiteral("navigationView"));
        setAccessibleName(QStringLiteral("Учебная координатная схема"));
    }

    void setReading(Position position, bool valid, const QString& system,
                    const QString& firstCondition, bool firstConditionMet,
                    const QString& secondCondition = QString(), bool secondConditionMet = true)
    {
        position_ = position;
        valid_ = valid;
        system_ = system;
        firstCondition_ = firstCondition;
        firstConditionMet_ = firstConditionMet;
        secondCondition_ = secondCondition;
        secondConditionMet_ = secondConditionMet;
        setAccessibleDescription(QStringLiteral("%1. %2. %3. %4")
                                     .arg(system_, valid_ ? QStringLiteral("Данные действительны")
                                                          : QStringLiteral("Данные недействительны"),
                                          firstCondition_, secondCondition_));
        update();
    }

protected:
    void paintEvent(QPaintEvent *) override
    {
        QPainter painter(this);
        painter.setRenderHint(QPainter::Antialiasing);
        painter.fillRect(rect(), QColor(240, 246, 245));
        painter.setPen(QColor(32, 59, 65));
        painter.drawText(QRect(12, 8, width() - 24, 23), Qt::AlignLeft,
                         QStringLiteral("Учебная координатная схема · %1").arg(system_));

        const auto drawCondition = [&painter](const QRectF& badge, const QString& text, bool met) {
            painter.setPen(Qt::NoPen);
            painter.setBrush(met ? QColor(218, 239, 226) : QColor(251, 225, 222));
            painter.drawRoundedRect(badge, 5, 5);
            painter.setPen(met ? QColor(24, 105, 67) : QColor(164, 43, 43));
            painter.drawText(badge.adjusted(8, 0, -8, 0), Qt::AlignVCenter | Qt::AlignLeft,
                             (met ? QStringLiteral("✓ ") : QStringLiteral("× ")) + text);
        };
        const qreal badgeWidth = secondCondition_.isEmpty() ? width() - 24 : (width() - 32) / 2.0;
        drawCondition(QRectF(12, 35, badgeWidth, 25), firstCondition_, firstConditionMet_);
        if (!secondCondition_.isEmpty()) {
            drawCondition(QRectF(20 + badgeWidth, 35, badgeWidth, 25),
                          secondCondition_, secondConditionMet_);
        }

        const QRectF plot(62, 78, width() - 88, height() - 108);
        painter.setPen(QPen(QColor(184, 204, 200), 1));
        for (int step = 0; step <= 4; ++step) {
            const qreal x = plot.left() + step * plot.width() / 4;
            const qreal y = plot.top() + step * plot.height() / 4;
            painter.drawLine(QPointF(x, plot.top()), QPointF(x, plot.bottom()));
            painter.drawLine(QPointF(plot.left(), y), QPointF(plot.right(), y));
        }
        painter.setPen(QColor(65, 89, 95));
        for (int step = 0; step <= 2; ++step) {
            const qreal y = plot.top() + step * plot.height() / 2;
            painter.drawText(QRectF(3, y - 10, 53, 20), Qt::AlignRight | Qt::AlignVCenter,
                             QStringLiteral("%1°").arg(56.0 - step * 0.25, 0, 'f', 2));
            const qreal x = plot.left() + step * plot.width() / 2;
            painter.drawText(QRectF(x - 32, plot.bottom() + 4, 64, 20), Qt::AlignCenter,
                             QStringLiteral("%1°").arg(37.3 + step * 0.3, 0, 'f', 2));
        }

        // The grid uses fixed bounds around the control coordinates from the assignment.
        const qreal longitude = qBound(0.0, (position_.longitude - 37.3) / 0.6, 1.0);
        const qreal latitude = qBound(0.0, (position_.latitude - 55.5) / 0.5, 1.0);
        const QPointF marker(plot.left() + longitude * plot.width(),
                             plot.top() + (1.0 - latitude) * plot.height());
        const QColor signal = valid_ ? QColor(24, 125, 77) : QColor(191, 55, 55);
        painter.setPen(QPen(signal, 2));
        painter.setBrush(QColor(signal.red(), signal.green(), signal.blue(), 45));
        painter.drawEllipse(marker, 19, 19);
        if (valid_) {
            painter.setBrush(signal);
            painter.drawEllipse(marker, 6, 6);
        } else {
            painter.drawLine(marker + QPointF(-7, -7), marker + QPointF(7, 7));
            painter.drawLine(marker + QPointF(-7, 7), marker + QPointF(7, -7));
        }
        painter.drawText(QRectF(marker.x() + 24, marker.y() - 12, 190, 24),
                         Qt::AlignVCenter | Qt::AlignLeft,
                         valid_ ? QStringLiteral("Положение подтверждено")
                                : QStringLiteral("Положение не подтверждено"));
    }

private:
    Position position_{55.75, 37.61, 150.0};
    bool valid_ = true;
    QString system_ = QStringLiteral("GPS");
    QString firstCondition_;
    QString secondCondition_;
    bool firstConditionMet_ = true;
    bool secondConditionMet_ = true;
};

NavigationPanel::NavigationPanel(QWidget *parent)
    : QWidget(parent)
    , systemSelector_(new QComboBox(this))
    , gpsControls_(new QGroupBox(QStringLiteral("Условия работы GPS"), this))
    , visualControls_(new QGroupBox(QStringLiteral("Условия визуальной навигации"), this))
    , satelliteCount_(new QSpinBox(this))
    , gpsValid_(new QCheckBox(QStringLiteral("Сигнал действителен"), this))
    , targetTracked_(new QCheckBox(QStringLiteral("Цель отслеживается"), this))
    , status_(new QLabel(this))
    , reason_(new QLabel(this))
    , coordinates_(new QLabel(this))
    , view_(new NavigationView(this))
{
    auto *layout = new QVBoxLayout(this);
    layout->setSpacing(7);
    auto *heading = new QLabel(QStringLiteral("GPS и визуальная навигация"), this);
    QFont headingFont = heading->font();
    headingFont.setPointSize(17);
    headingFont.setBold(true);
    heading->setFont(headingFont);
    layout->addWidget(heading);

    auto *selection = new QHBoxLayout;
    selection->addWidget(new QLabel(QStringLiteral("Система:"), this));
    systemSelector_->addItems({QStringLiteral("GPS"),
                               QStringLiteral("Визуальная навигация")});
    systemSelector_->setObjectName(QStringLiteral("navigationSystemSelector"));
    selection->addWidget(systemSelector_, 1);
    auto *checkButton = new QPushButton(QStringLiteral("Проверить навигацию"), this);
    checkButton->setObjectName(QStringLiteral("checkNavigationButton"));
    selection->addWidget(checkButton);
    layout->addLayout(selection);

    auto *gpsForm = new QHBoxLayout(gpsControls_);
    satelliteCount_->setRange(0, 30);
    satelliteCount_->setValue(gps_.satellites());
    satelliteCount_->setObjectName(QStringLiteral("satelliteCount"));
    satelliteCount_->setMaximumWidth(80);
    gpsForm->addWidget(new QLabel(QStringLiteral("Спутников:"), gpsControls_));
    gpsForm->addWidget(satelliteCount_);
    gpsForm->addWidget(new QLabel(QStringLiteral("нужно не менее 4"), gpsControls_));
    gpsForm->addStretch();
    gpsValid_->setChecked(true);
    gpsValid_->setObjectName(QStringLiteral("gpsValidCheck"));
    gpsForm->addWidget(gpsValid_);
    layout->addWidget(gpsControls_);

    auto *visualForm = new QHBoxLayout(visualControls_);
    targetTracked_->setChecked(true);
    targetTracked_->setObjectName(QStringLiteral("targetTrackedCheck"));
    visualForm->addWidget(targetTracked_);
    visualForm->addStretch();
    layout->addWidget(visualControls_);

    layout->addWidget(view_, 1);
    layout->addWidget(coordinates_);
    layout->addWidget(status_);
    reason_->setWordWrap(true);
    reason_->setObjectName(QStringLiteral("navigationValidityReason"));
    status_->setObjectName(QStringLiteral("navigationValidityStatus"));
    layout->addWidget(reason_);

    connect(systemSelector_, QOverload<int>::of(&QComboBox::currentIndexChanged),
            this, [this] { refresh(); });
    connect(satelliteCount_, QOverload<int>::of(&QSpinBox::valueChanged),
            this, [this](int count) {
                gps_.set_satellites(count);
                refresh();
            });
    connect(gpsValid_, &QCheckBox::toggled, this, [this](bool valid) {
        gps_.set_valid(valid);
        refresh();
    });
    connect(targetTracked_, &QCheckBox::toggled, this, [this](bool tracked) {
        visual_.set_target_tracked(tracked);
        refresh();
    });
    connect(checkButton, &QPushButton::clicked, this, [this] {
        print_navigation_status(selectedSystem());
        refresh();
    });
    refresh();
}

const NavigationSystem& NavigationPanel::selectedSystem() const
{
    return systemSelector_->currentIndex() == 0
        ? static_cast<const NavigationSystem&>(gps_)
        : static_cast<const NavigationSystem&>(visual_);
}

void NavigationPanel::refresh()
{
    const bool showGps = systemSelector_->currentIndex() == 0;
    gpsControls_->setVisible(showGps);
    visualControls_->setVisible(!showGps);

    const NavigationSystem& navigation = selectedSystem();
    const Position position = navigation.get_position();
    const bool valid = navigation.is_valid();
    if (showGps) {
        const bool enoughSatellites = gps_.satellites() >= 4;
        const bool signalValid = gpsValid_->isChecked();
        view_->setReading(position, valid, navigation.system_name(),
                          QStringLiteral("Спутников: %1 / нужно ≥4").arg(gps_.satellites()),
                          enoughSatellites, QStringLiteral("Сигнал действителен"), signalValid);
        if (valid) {
            reason_->setText(QStringLiteral("GPS: выполнены оба условия — не менее 4 спутников и действительный сигнал."));
        } else if (!enoughSatellites && !signalValid) {
            reason_->setText(QStringLiteral("Причина: спутников меньше 4 и сигнал недействителен."));
        } else if (!enoughSatellites) {
            reason_->setText(QStringLiteral("Причина: спутников %1; для GPS требуется не менее 4.")
                                 .arg(gps_.satellites()));
        } else {
            reason_->setText(QStringLiteral("Причина: сигнал GPS недействителен, хотя спутников достаточно."));
        }
    } else {
        view_->setReading(position, valid, navigation.system_name(),
                          QStringLiteral("Цель отслеживается"), targetTracked_->isChecked());
        reason_->setText(valid ? QStringLiteral("Визуальная навигация: цель отслеживается, положение подтверждено.")
                               : QStringLiteral("Причина: цель потеряна, визуальная навигация недействительна."));
    }
    coordinates_->setText(QStringLiteral("Координаты: %1, %2; высота: %3 м")
                              .arg(position.latitude).arg(position.longitude)
                              .arg(position.altitude));
    status_->setText(valid ? QStringLiteral("Статус: навигация действительна")
                           : QStringLiteral("Статус: навигация недействительна"));
    status_->setStyleSheet(valid ? QStringLiteral("color: #197444; font-weight: bold;")
                                 : QStringLiteral("color: #b43131; font-weight: bold;"));
}
