#include "mainwindow.h"
#include "navigationpanel.h"
#include "sensorpanel.h"
#include "uav.h"
#include "./ui_mainwindow.h"

#include <QComboBox>
#include <QHBoxLayout>
#include <QLabel>
#include <QPainter>
#include <QPainterPath>
#include <QProgressBar>
#include <QPushButton>
#include <QStatusBar>
#include <QTabWidget>
#include <QTimer>
#include <QVBoxLayout>

#include <memory>

class FlightView : public QWidget {
public:
    explicit FlightView(QWidget *parent = nullptr) : QWidget(parent)
    {
        setMinimumHeight(300);
        setObjectName(QStringLiteral("flightView"));
    }

    void setVehicle(int index)
    {
        vehicleIndex = index;
        flightPhase = FlightPhase::Ready;
        flightStep = 0;
        update();
    }

    void setFlightState(FlightPhase phase, int step)
    {
        flightPhase = phase;
        flightStep = step;
        update();
    }

    QString description() const
    {
        if (flightPhase == FlightPhase::Ready) {
            return QStringLiteral("Готов к испытанию");
        }
        if (flightPhase == FlightPhase::Complete) {
            return QStringLiteral("Испытание завершено — аппарат на земле");
        }
        if (vehicleIndex == 0) {
            return flightPhase == FlightPhase::Takeoff
                ? QStringLiteral("Вертикальный взлёт") : QStringLiteral("Вертикальная посадка");
        }
        if (flightPhase == FlightPhase::Takeoff) {
            return flightStep < 20 ? QStringLiteral("Разбег по полосе")
                                  : QStringLiteral("Взлёт и набор высоты");
        }
        return flightStep < 80 ? QStringLiteral("Планирование и снижение")
                              : QStringLiteral("Посадка и пробег по полосе");
    }

protected:
    void paintEvent(QPaintEvent *) override
    {
        QPainter painter(this);
        painter.setRenderHint(QPainter::Antialiasing);

        const int ground = height() - 70;
        QLinearGradient sky(0, 0, 0, ground);
        sky.setColorAt(0, QColor(210, 232, 251));
        sky.setColorAt(1, QColor(241, 248, 252));
        painter.fillRect(rect(), sky);
        painter.fillRect(0, ground, width(), height() - ground, QColor(160, 188, 154));
        painter.setPen(QPen(QColor(97, 134, 98), 2));
        painter.drawLine(0, ground, width(), ground);

        const auto scenePoint = [this, ground](QPointF normalized) {
            return QPointF(normalized.x() * width(),
                           ground - 18 - normalized.y() * (ground - 80));
        };
        QPainterPath route;
        route.moveTo(scenePoint(flight_position(vehicleIndex == 0, FlightPhase::Ready, 0)));
        for (FlightPhase phase : {FlightPhase::Takeoff, FlightPhase::Landing}) {
            for (int step = 0; step <= 100; step += 2) {
                route.lineTo(scenePoint(flight_position(vehicleIndex == 0, phase, step / 100.0)));
            }
        }
        painter.setPen(QPen(QColor(109, 150, 181), 2, Qt::DashLine));
        painter.drawPath(route);
        if (vehicleIndex == 1) {
            painter.fillRect(32, ground - 2, width() - 64, 26, QColor(74, 85, 94));
            painter.setPen(QPen(Qt::white, 2, Qt::DashLine));
            painter.drawLine(48, ground + 12, width() - 48, ground + 12);
        } else {
            painter.fillRect(width() / 2 - 65, ground + 6, 130, 13, QColor(83, 103, 115));
        }

        painter.setPen(QColor(39, 67, 88));
        painter.drawText(QRect(16, 12, width() - 32, 24), Qt::AlignLeft,
                         vehicleIndex == 0 ? QStringLiteral("Квадрокоптер")
                                           : QStringLiteral("Самолётный БПЛА"));
        painter.drawText(QRect(16, height() - 32, width() - 32, 24), Qt::AlignCenter,
                         vehicleIndex == 0 ? QStringLiteral("Вертикальная траектория")
                                           : QStringLiteral("Взлётная и посадочная полоса"));

        const QPointF position = scenePoint(flight_position(
            vehicleIndex == 0, flightPhase, flightStep / 100.0));
        painter.save();
        painter.translate(position);
        painter.setPen(QPen(QColor(31, 56, 72), 3));
        painter.setBrush(QColor(49, 108, 163));

        if (vehicleIndex == 0) {
            painter.drawLine(-31, -2, 31, -2);
            painter.drawEllipse(QRectF(-16, -9, 32, 18));
            painter.setBrush(QColor(39, 57, 73));
            painter.drawEllipse(QRectF(-37, -10, 13, 6));
            painter.drawEllipse(QRectF(24, -10, 13, 6));
            painter.drawLine(-22, 7, -14, 15);
            painter.drawLine(22, 7, 14, 15);
        } else {
            const QPolygonF aircraft({QPointF(-37, 4), QPointF(34, -4),
                                      QPointF(39, 0), QPointF(-37, 9)});
            painter.drawPolygon(aircraft);
            painter.drawLine(-7, 3, -23, -16);
            painter.drawLine(-7, 3, -25, 19);
        }
        painter.restore();
    }

private:
    int vehicleIndex = 0;
    FlightPhase flightPhase = FlightPhase::Ready;
    int flightStep = 0;
};

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , flightView(new FlightView(this))
    , vehicleSelector(new QComboBox(this))
    , statusLabel(new QLabel(this))
    , startButton(new QPushButton(QStringLiteral("Начать испытание"), this))
    , animationTimer(new QTimer(this))
    , cycleProgress(new QProgressBar(this))
{
    ui->setupUi(this);
    setWindowTitle(QStringLiteral("КР №2 — вариант 1"));
    resize(960, 650);

    auto *rootLayout = new QVBoxLayout(ui->centralwidget);
    auto *tabs = new QTabWidget(ui->centralwidget);
    rootLayout->addWidget(tabs);

    auto *flightTab = new QWidget(tabs);
    auto *layout = new QVBoxLayout(flightTab);
    auto *heading = new QLabel(QStringLiteral("Виртуальные классы летательных аппаратов"), this);
    QFont headingFont = heading->font();
    headingFont.setPointSize(17);
    headingFont.setBold(true);
    heading->setFont(headingFont);
    layout->addWidget(heading);

    auto *controls = new QHBoxLayout;
    controls->addWidget(new QLabel(QStringLiteral("Аппарат:"), this));
    vehicleSelector->addItems({QStringLiteral("Квадрокоптер"),
                               QStringLiteral("Самолётный БПЛА")});
    vehicleSelector->setObjectName(QStringLiteral("vehicleSelector"));
    startButton->setObjectName(QStringLiteral("flightStartButton"));
    controls->addWidget(vehicleSelector, 1);
    controls->addWidget(startButton);
    layout->addLayout(controls);

    layout->addWidget(flightView, 1);
    statusLabel->setText(QStringLiteral("Выберите аппарат и начните испытание."));
    layout->addWidget(statusLabel);
    statusLabel->setObjectName(QStringLiteral("flightStatus"));
    cycleProgress->setObjectName(QStringLiteral("flightProgress"));
    cycleProgress->setRange(0, 100);
    cycleProgress->setValue(0);
    cycleProgress->setFormat(QStringLiteral("Испытание: %p%"));
    layout->addWidget(cycleProgress);
    tabs->addTab(flightTab, QStringLiteral("Задание 1 — БПЛА"));
    tabs->addTab(new SensorPanel(tabs), QStringLiteral("Задание 2 — сенсоры"));
    tabs->addTab(new NavigationPanel(tabs), QStringLiteral("Задание 3 — навигация"));
    statusBar()->hide();

    connect(vehicleSelector, QOverload<int>::of(&QComboBox::currentIndexChanged),
            this, [this](int index) {
                flightView->setVehicle(index);
                cycleProgress->setValue(0);
                statusLabel->setText(flightView->description());
            });
    connect(startButton, &QPushButton::clicked, this, &MainWindow::startFlight);
    connect(animationTimer, &QTimer::timeout, this, &MainWindow::advanceAnimation);
    animationTimer->setInterval(25);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::startFlight()
{
    if (vehicleSelector->currentIndex() == 0) {
        activeVehicle = std::make_unique<Quadcopter>();
    } else {
        activeVehicle = std::make_unique<FixedWingUAV>();
    }
    begin_flight_test(*activeVehicle);

    animationPhase = FlightPhase::Takeoff;
    animationStep = 0;
    flightView->setFlightState(animationPhase, animationStep);
    statusLabel->setText(flightView->description());
    cycleProgress->setValue(0);
    startButton->setEnabled(false);
    vehicleSelector->setEnabled(false);
    animationTimer->start();
}

void MainWindow::advanceAnimation()
{
    animationStep += 1;
    if (animationStep >= 100) {
        animationStep = 0;
        if (animationPhase == FlightPhase::Takeoff) {
            animationPhase = FlightPhase::Landing;
            activeVehicle->land();
        } else {
            animationPhase = FlightPhase::Complete;
            animationTimer->stop();
            complete_flight_test(*activeVehicle);
            activeVehicle.reset();
            startButton->setEnabled(true);
            vehicleSelector->setEnabled(true);
        }
    }
    flightView->setFlightState(animationPhase, animationStep);
    statusLabel->setText(flightView->description());
    cycleProgress->setValue(animationPhase == FlightPhase::Complete ? 100
        : animationPhase == FlightPhase::Landing ? 50 + animationStep / 2
                                                 : animationStep / 2);
}
