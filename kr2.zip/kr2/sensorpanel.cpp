#include "sensorpanel.h"

#include <QCheckBox>
#include <QGroupBox>
#include <QHBoxLayout>
#include <QLabel>
#include <QProgressBar>
#include <QPushButton>
#include <QVBoxLayout>
#include <QtMath>

#include <vector>

namespace {
const std::array<QString, 3> units = {QStringLiteral("рад/с"),
                                     QStringLiteral("м/с²"),
                                     QStringLiteral("гПа")};
const std::array<QString, 3> titles = {QStringLiteral("Гироскоп (Gyroscope)"),
                                      QStringLiteral("Акселерометр (Accelerometer)"),
                                      QStringLiteral("Барометр (Barometer)")};
constexpr std::array<double, 3> minimums = {0.0, 0.0, 900.0};
constexpr std::array<double, 3> maximums = {2.0, 15.0, 1100.0};
}

SensorPanel::SensorPanel(QWidget *parent)
    : QWidget(parent)
    , sensors_{&gyroscope_, &accelerometer_, &barometer_}
    , summary_(new QLabel(this))
{
    auto *layout = new QVBoxLayout(this);
    auto *heading = new QLabel(QStringLiteral("Сенсоры полётного контроллера"), this);
    QFont headingFont = heading->font();
    headingFont.setPointSize(17);
    headingFont.setBold(true);
    heading->setFont(headingFont);
    layout->addWidget(heading);
    auto *description = new QLabel(
        QStringLiteral("Шкалы показывают показания в учебных диапазонах. "
                       "Снимите флажок готовности или сымитируйте отказ, чтобы проверить обработку ошибки."), this);
    description->setWordWrap(true);
    layout->addWidget(description);

    for (int index = 0; index < 3; ++index) {
        auto *group = new QGroupBox(titles[index], this);
        auto *row = new QHBoxLayout(group);
        auto *value = new QLabel(group);
        value->setObjectName(QStringLiteral("sensor_value_%1").arg(index));
        value->setMinimumWidth(125);
        row->addWidget(value);
        valueLabels_[index] = value;

        auto *scale = new QVBoxLayout;
        auto *gauge = new QProgressBar(group);
        gauge->setObjectName(QStringLiteral("sensor_gauge_%1").arg(index));
        gauge->setRange(0, 1000);
        gauge->setTextVisible(false);
        scale->addWidget(gauge);
        auto *limits = new QHBoxLayout;
        limits->addWidget(new QLabel(QStringLiteral("%1 %2")
                                         .arg(minimums[index]).arg(units[index]), group));
        limits->addStretch();
        limits->addWidget(new QLabel(QStringLiteral("%1 %2")
                                         .arg(maximums[index]).arg(units[index]), group));
        scale->addLayout(limits);
        row->addLayout(scale, 1);
        gauges_[index] = gauge;

        auto *state = new QVBoxLayout;
        auto *ready = new QCheckBox(QStringLiteral("Готов"), group);
        ready->setObjectName(QStringLiteral("sensor_ready_%1").arg(index));
        ready->setChecked(true);
        state->addWidget(ready);
        auto *indicator = new QLabel(group);
        indicator->setObjectName(QStringLiteral("sensor_state_%1").arg(index));
        indicator->setMinimumWidth(130);
        state->addWidget(indicator);
        row->addLayout(state);
        stateLabels_[index] = indicator;
        readyChecks_[index] = ready;
        connect(ready, &QCheckBox::toggled, this, [this, index](bool isReady) {
            sensors_[index]->set_ready(isReady);
            updateStatus();
        });
        layout->addWidget(group);
    }

    auto *actions = new QHBoxLayout;
    auto *checkButton = new QPushButton(QStringLiteral("Проверить сенсоры"), this);
    auto *failureButton = new QPushButton(QStringLiteral("Сымитировать отказ"), this);
    auto *resetButton = new QPushButton(QStringLiteral("Восстановить"), this);
    checkButton->setObjectName(QStringLiteral("check_sensors"));
    failureButton->setObjectName(QStringLiteral("simulate_sensor_failure"));
    resetButton->setObjectName(QStringLiteral("restore_sensors"));
    summary_->setObjectName(QStringLiteral("sensor_summary"));
    actions->addWidget(checkButton);
    actions->addWidget(failureButton);
    actions->addWidget(resetButton);
    actions->addStretch();
    layout->addLayout(actions);
    layout->addWidget(summary_);
    layout->addStretch();

    connect(checkButton, &QPushButton::clicked, this, [this] {
        std::vector<Sensor*> pointers(sensors_.begin(), sensors_.end());
        check_sensors(pointers);
        updateStatus();
    });
    connect(failureButton, &QPushButton::clicked, this, [this] {
        readyChecks_[0]->setChecked(false);
    });
    connect(resetButton, &QPushButton::clicked, this, [this] {
        for (QCheckBox *check : readyChecks_) {
            check->setChecked(true);
        }
    });
    updateStatus();
}

void SensorPanel::updateStatus()
{
    bool allReady = true;
    for (int index = 0; index < 3; ++index) {
        const bool ready = sensors_[index]->is_ready();
        gauges_[index]->setEnabled(ready);
        if (ready) {
            const double value = sensors_[index]->read();
            valueLabels_[index]->setText(QStringLiteral("%1 %2").arg(value).arg(units[index]));
            const double fraction = (value - minimums[index]) / (maximums[index] - minimums[index]);
            gauges_[index]->setValue(qBound(0, qRound(fraction * 1000.0), 1000));
            stateLabels_[index]->setText(QStringLiteral("● Готов"));
            stateLabels_[index]->setStyleSheet(QStringLiteral("color: #197444; font-weight: bold;"));
        } else {
            valueLabels_[index]->setText(QStringLiteral("Нет данных"));
            gauges_[index]->setValue(0);
            stateLabels_[index]->setText(QStringLiteral("● Не готов"));
            stateLabels_[index]->setStyleSheet(QStringLiteral("color: #b43131; font-weight: bold;"));
        }
        allReady = allReady && ready;
    }
    summary_->setText(allReady ? QStringLiteral("Все сенсоры готовы")
                               : QStringLiteral("Сбой сенсора — данные недоступны"));
    summary_->setStyleSheet(allReady ? QStringLiteral("color: #197444; font-weight: bold;")
                                     : QStringLiteral("color: #b43131; font-weight: bold;"));
}
