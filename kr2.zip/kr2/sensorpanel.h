#ifndef SENSORPANEL_H
#define SENSORPANEL_H

#include "sensor.h"

#include <QWidget>

#include <array>

class QCheckBox;
class QLabel;
class QProgressBar;

class SensorPanel : public QWidget {
public:
    explicit SensorPanel(QWidget *parent = nullptr);

private:
    void updateStatus();

    Gyroscope gyroscope_;
    Accelerometer accelerometer_;
    Barometer barometer_;
    std::array<FlightSensor*, 3> sensors_;
    std::array<QCheckBox*, 3> readyChecks_{};
    std::array<QProgressBar*, 3> gauges_{};
    std::array<QLabel*, 3> valueLabels_{};
    std::array<QLabel*, 3> stateLabels_{};
    QLabel *summary_;
};

#endif // SENSORPANEL_H
