#include "mainwindow.h"
#include "uav.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    if (a.arguments().contains(QStringLiteral("--flight-test"))) {
        Quadcopter quadcopter;
        FixedWingUAV fixedWing;
        run_flight_test(quadcopter);
        run_flight_test(fixedWing);
        return 0;
    }
    MainWindow w;
    w.show();
    return QApplication::exec();
}
