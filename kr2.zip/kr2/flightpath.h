#ifndef FLIGHTPATH_H
#define FLIGHTPATH_H

#include <QPointF>
#include <QtGlobal>

enum class FlightPhase { Ready, Takeoff, Landing, Complete };

// Coordinates: x is a fraction of scene width, y is relative height above ground.
inline QPointF flight_position(bool vertical, FlightPhase phase, qreal progress)
{
    const qreal t = qBound(0.0, progress, 1.0);
    const auto smooth = [](qreal value) {
        return value * value * (3.0 - 2.0 * value);
    };
    if (vertical) {
        const qreal altitude = phase == FlightPhase::Takeoff ? smooth(t)
            : phase == FlightPhase::Landing ? 1.0 - smooth(t) : 0.0;
        return {0.5, altitude};
    }
    if (phase == FlightPhase::Ready) {
        return {0.1, 0.0};
    }
    if (phase == FlightPhase::Complete) {
        return {0.9, 0.0};
    }
    if (phase == FlightPhase::Takeoff) {
        const qreal climb = qBound(0.0, (t - 0.2) / 0.8, 1.0);
        return {0.1 + 0.4 * t, 0.75 * smooth(climb)};
    }
    const qreal descent = qBound(0.0, t / 0.8, 1.0);
    return {0.5 + 0.4 * t, 0.75 * (1.0 - smooth(descent))};
}

#endif // FLIGHTPATH_H
