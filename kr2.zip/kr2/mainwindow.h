#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "flightpath.h"

#include <memory>

class FlightView;
class QComboBox;
class QLabel;
class QPushButton;
class QProgressBar;
class QTimer;
class UAV;

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow() override;

private:
    void startFlight();
    void advanceAnimation();

    Ui::MainWindow *ui;
    FlightView *flightView;
    QComboBox *vehicleSelector;
    QLabel *statusLabel;
    QPushButton *startButton;
    QTimer *animationTimer;
    QProgressBar *cycleProgress;
    std::unique_ptr<UAV> activeVehicle;
    int animationStep = 0;
    FlightPhase animationPhase = FlightPhase::Ready;
};
#endif // MAINWINDOW_H
