#include "navigation.h"

#include <QDebug>

GPSNavigation::GPSNavigation(Position position, int satellites, bool valid)
    : position_(position), satellites_(satellites), valid_(valid) {}

Position GPSNavigation::get_position() const
{
    return position_;
}

bool GPSNavigation::is_valid() const
{
    return satellites_ >= 4 && valid_;
}

QString GPSNavigation::system_name() const
{
    return QStringLiteral("GPS");
}

int GPSNavigation::satellites() const
{
    return satellites_;
}

void GPSNavigation::set_satellites(int satellites)
{
    satellites_ = satellites;
}

void GPSNavigation::set_valid(bool valid)
{
    valid_ = valid;
}

VisualNavigation::VisualNavigation(Position position, bool target_tracked)
    : position_(position), target_tracked_(target_tracked) {}

Position VisualNavigation::get_position() const
{
    return position_;
}

bool VisualNavigation::is_valid() const
{
    return target_tracked_;
}

QString VisualNavigation::system_name() const
{
    return QStringLiteral("Visual navigation");
}

void VisualNavigation::set_target_tracked(bool target_tracked)
{
    target_tracked_ = target_tracked;
}

void print_navigation_status(const NavigationSystem& navigation)
{
    const Position position = navigation.get_position();
    qDebug().noquote() << "Navigation system:" << navigation.system_name();
    qDebug().noquote() << QStringLiteral("Position: %1, %2, %3")
                              .arg(position.latitude).arg(position.longitude)
                              .arg(position.altitude);
    qDebug().noquote() << "Status:" << (navigation.is_valid() ? "Valid" : "Invalid");
}
